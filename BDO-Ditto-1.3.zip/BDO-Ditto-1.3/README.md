# BDO-Ditto
A small tool to help transfer some appearance data from one character to another.
